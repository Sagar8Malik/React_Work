import "./App.css";
import ProductScreens from "./Screens/ProductScreens";
function App() {
  return <ProductScreens />;
}

export default App;
